<?php
header('Location: ../');
?>

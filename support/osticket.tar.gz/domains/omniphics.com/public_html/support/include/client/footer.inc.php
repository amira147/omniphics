 <div style="clear:both"></div> 
 </div>
 <div id="footer">Copyright &copy; Omniphics Sdn Bhd. All rights reserved</div>
 <div align="center">
     <a id="powered_by" href="http://www.omniphics.com">www.omniphics.com</a></div>
</div>
</body>
</html>
